import { useState } from "react"

import UserData from "./classbased.tsx"

function App() {
    // 声明一个boolean布尔类型的状态变量
    // 用于卸载UserData组件
    const [show, setShow] = useState(true)

    // 声明一个userId状态变量
    const [userId, setUserId] = useState(1)

    return (
        <>
            {/* 条件渲染 */}
            { show && <UserData userId={userId}/> }
            <div>
                <button onClick={() => setUserId(userId - 1)}>-1</button>
                userId: {userId}
                <button onClick={() => setUserId(userId + 1)}>+1</button>
            </div>
            <button onClick={() => setShow(false)}>卸载组件</button>
        </>
    )
}

export default App