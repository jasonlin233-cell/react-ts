import { useEffect, useState } from "react"

// 定义一个User对象类型
type User = {
    id: number
    name: string
    email: string
}

// 定义一个Props类型
type Props = {
    userId: number
}

// 函数组件
// 将Props类型 注解到props参数的位置
function UserData(props: Props) {
    // 声明一个状态变量seconds
    const [seconds, setSeconds] = useState(0)

    // 声明一个user类型的状态对象
    const [user, setUser] = useState<User | null>(null)

    // 向后台发送网络请求
    const fetchUserData = () => {
        // fetch(`https://secret.url/user/${props.userId}`)
        // .then(response => response.json())
        // .then(data => setUser(data))
        // .catch(error => console.error('Error fetching user data:', error));

        // 这里我用自己本地创建的db.json存放数据user
        // 因为user数组里面有多个元素，传递参数之后，会得到只剩下一个元素的数组data
        // 因此是setUser(data[0]) 而不是setUser(data)
        fetch(`http://localhost:3004/user?id=${props.userId}`)
        .then(response => response.json())
        .then(data => setUser(data[0]))
        .catch(error => console.error('Error fetching user data:', error));
    }

    // 空依赖数组 只在最开始渲染的时候执行一次
    useEffect(() => {
        // 开启定时器 每隔1秒seconds+1
        const intervalId = setInterval(() => {
            // 使用setSeconds的回调形式，使每次定时器触发时，seconds的值都会递增
            setSeconds(seconds => seconds + 1)
            console.log('定时器执行中')
        }, 1000)
        console.log(props.userId)
        // 组件卸载时，自动清除定时器
        return () => {
            clearInterval(intervalId)
        }
    }, [])


    // 初始渲染 以及 每次依赖项props.userId更新时都会执行一次
    useEffect(() => {
        fetchUserData()
        console.log('userId变化了,重新渲染并发起一次网络请求')
    }, [props.userId])


    return (
        <div>
            <h1>User Data Component</h1>
            {user ? (
                <div>
                    <p>Name: {user.name}</p>
                    <p>Email: {user.email}</p>
                </div>
            ) : (
                <p>Loading user data...</p>
            )}
            <p>Timer: {seconds} seconds</p>
        </div>
    )
}


export default UserData